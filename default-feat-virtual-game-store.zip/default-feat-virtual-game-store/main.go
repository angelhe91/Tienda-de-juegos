package main

import (
	"fmt"
	"html/template"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"time"
)

// Main function to start the server
func main() {
	// Create static images directory if it doesn't exist
	os.MkdirAll("static/images", os.ModePerm)

	// Create initial admin user
	adminPassword, _ := hashPassword("1234")
	users["angelhe91"] = User{
		Username:     "angelhe91",
		Email:        "Angelhe91@gmail.com",
		PasswordHash: adminPassword,
		Role:         "admin",
	}

	// Define handlers
	http.HandleFunc("/", homeHandler)
	http.HandleFunc("/checkout", checkoutHandler)
	http.HandleFunc("/confirm-payment", confirmPaymentHandler)
	http.HandleFunc("/confirmation", confirmationPageHandler)
	http.HandleFunc("/admin", adminRequired(adminHandler))
	http.HandleFunc("/admin/users", adminRequired(viewUsersHandler))
	http.HandleFunc("/admin/create-user", adminRequired(createUserHandler))
	http.HandleFunc("/admin/delete-user", adminRequired(deleteUserHandler))
	http.HandleFunc("/admin/change-password", adminRequired(adminChangePasswordPageHandler))
	http.HandleFunc("/admin/set-password", adminRequired(adminSetPasswordHandler))
	http.HandleFunc("/admin/approve-orders", adminRequired(viewPendingOrdersHandler))
	http.HandleFunc("/admin/approve-form", adminRequired(approvalFormHandler))
	http.HandleFunc("/admin/process-approval", adminRequired(processApprovalHandler))
	http.HandleFunc("/admin/update-rate", adminRequired(updateRateHandler))
	http.HandleFunc("/admin/upload-game", adminRequired(uploadGameHandler))
	http.HandleFunc("/reports", adminRequired(reportsHandler))
	http.HandleFunc("/login", loginHandler)
	http.HandleFunc("/register", registerHandler)
	http.HandleFunc("/logout", logoutHandler)
	http.HandleFunc("/cart", viewCartHandler)
	http.HandleFunc("/cart/add", addToCartHandler)

	// Profile handlers
	http.HandleFunc("/profile", profileHandler)
	http.HandleFunc("/profile/change-password", changePasswordHandler)
	http.HandleFunc("/my-games", myGamesHandler)

	// Serve static files
	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("static"))))

	fmt.Println("Server starting on port 8080...")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

func homeHandler(w http.ResponseWriter, r *http.Request) {
	c, err := r.Cookie("session_token")
	isLoggedIn := false
	isAdmin := false
	if err == nil {
		username, ok := getUsernameFromSession(c.Value)
		if ok {
			isLoggedIn = true
			isAdmin = users[username].Role == "admin"
		}
	}
	gamesByConsole := make(map[string][]Game)
	for _, game := range games {
		gamesByConsole[game.Console] = append(gamesByConsole[game.Console], game)
	}

	data := struct {
		IsLoggedIn     bool
		IsAdmin        bool
		GamesByConsole map[string][]Game
	}{
		IsLoggedIn:     isLoggedIn,
		IsAdmin:        isAdmin,
		GamesByConsole: gamesByConsole,
	}
	render(w, "index.html", data)
}

func render(w http.ResponseWriter, tmplName string, data interface{}) {
	tmpl, err := template.ParseFiles("templates/layout.html", "templates/"+tmplName)
	if err != nil {
		http.Error(w, "Error parsing templates: "+err.Error(), http.StatusInternalServerError)
		return
	}
	err = tmpl.ExecuteTemplate(w, "layout", data)
	if err != nil {
		http.Error(w, "Error executing template: "+err.Error(), http.StatusInternalServerError)
	}
}

func renderMinimal(w http.ResponseWriter, tmplName string, data interface{}) {
	tmpl, err := template.ParseFiles("templates/layout_minimal.html", "templates/"+tmplName)
	if err != nil {
		http.Error(w, "Error parsing templates: "+err.Error(), http.StatusInternalServerError)
		return
	}
	err = tmpl.ExecuteTemplate(w, "layout", data)
	if err != nil {
		http.Error(w, "Error executing template: "+err.Error(), http.StatusInternalServerError)
	}
}

func adminRequired(handler http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		c, err := r.Cookie("session_token")
		if err != nil {
			http.Redirect(w, r, "/login", http.StatusFound)
			return
		}
		username, ok := getUsernameFromSession(c.Value)
		if !ok {
			http.Redirect(w, r, "/login", http.StatusFound)
			return
		}
		user, ok := users[username]
		if !ok || user.Role != "admin" {
			http.Redirect(w, r, "/", http.StatusForbidden) // Or show a 403 page
			return
		}
		// Pass a special value in the context if needed, or just call the handler
		handler(w, r)
	}
}

type CartItem struct {
	Game     Game
	Quantity int
	Subtotal float64
}

func viewCartHandler(w http.ResponseWriter, r *http.Request) {
	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	username, ok := getUsernameFromSession(c.Value)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	userCart, exists := carts[username]
	if !exists {
		userCart = make(map[int]int)
	}
	var items []CartItem
	var totalPrice float64
	for gameID, quantity := range userCart {
		var game Game
		for _, g := range games {
			if g.ID == gameID {
				game = g
				break
			}
		}
		subtotal := game.PriceUSD * float64(quantity)
		totalPrice += subtotal
		items = append(items, CartItem{
			Game:     game,
			Quantity: quantity,
			Subtotal: subtotal,
		})
	}
	data := struct {
		IsLoggedIn bool
		IsAdmin    bool
		Items      []CartItem
		TotalPrice float64
	}{
		IsLoggedIn: true,
		IsAdmin:    users[username].Role == "admin",
		Items:      items,
		TotalPrice: totalPrice,
	}
	render(w, "cart.html", data)
}

func addToCartHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}
	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	username, ok := getUsernameFromSession(c.Value)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	gameIDStr := r.FormValue("game_id")
	gameID, _ := strconv.Atoi(gameIDStr)
	if _, ok := carts[username]; !ok {
		carts[username] = make(map[int]int)
	}
	carts[username][gameID]++
	log.Printf("User '%s' added game ID %d to cart.", username, gameID)
	http.Redirect(w, r, "/cart", http.StatusFound)
}

func registerHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		username := r.FormValue("username")
		password := r.FormValue("password")
		email := r.FormValue("email")

		if _, exists := users[username]; exists {
			data := struct{ Error string }{Error: "Username already exists"}
			renderMinimal(w, "register.html", data)
			return
		}
		hashedPassword, err := hashPassword(password)
		if err != nil {
			http.Error(w, "Server error, unable to create your account.", http.StatusInternalServerError)
			return
		}
		newUser := User{
			Username:     username,
			Email:        email,
			PasswordHash: hashedPassword,
			Role:         "client",
		}
		users[username] = newUser
		log.Printf("New user registered: %s", username)

		// Send confirmation email
		go sendRegistrationConfirmation(newUser)

		sessionToken := createSession(username)
		http.SetCookie(w, &http.Cookie{
			Name:    "session_token",
			Value:   sessionToken,
			Expires: time.Now().Add(120 * time.Minute),
		})
		http.Redirect(w, r, "/", http.StatusFound)
	} else {
		renderMinimal(w, "register.html", nil)
	}
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		username := r.FormValue("username")
		password := r.FormValue("password")
		user, exists := users[username]
		if !exists || !checkPasswordHash(password, user.PasswordHash) {
			data := struct{ Error string }{Error: "Invalid username or password"}
			renderMinimal(w, "login.html", data)
			return
		}
		sessionToken := createSession(username)
		http.SetCookie(w, &http.Cookie{
			Name:    "session_token",
			Value:   sessionToken,
			Expires: time.Now().Add(120 * time.Minute),
		})
		http.Redirect(w, r, "/", http.StatusFound)
	} else {
		renderMinimal(w, "login.html", nil)
	}
}

func logoutHandler(w http.ResponseWriter, r *http.Request) {
	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/", http.StatusFound)
		return
	}
	deleteSession(c.Value)
	http.SetCookie(w, &http.Cookie{
		Name:    "session_token",
		Value:   "",
		Expires: time.Now(),
	})
	http.Redirect(w, r, "/login", http.StatusFound)
}

func checkoutHandler(w http.ResponseWriter, r *http.Request) {
	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	username, ok := getUsernameFromSession(c.Value)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}

	userCart, exists := carts[username]
	if !exists || len(userCart) == 0 {
		http.Redirect(w, r, "/cart", http.StatusFound)
		return
	}

	var items []CartItem
	var totalPriceUSD float64
	for gameID, quantity := range userCart {
		var game Game
		for _, g := range games {
			if g.ID == gameID {
				game = g
				break
			}
		}
		subtotal := game.PriceUSD * float64(quantity)
		totalPriceUSD += subtotal
		items = append(items, CartItem{
			Game:     game,
			Quantity: quantity,
			Subtotal: subtotal,
		})
	}

	totalPriceBs := totalPriceUSD * settings.ExchangeRate

	data := struct {
		IsLoggedIn    bool
		IsAdmin       bool
		Items         []CartItem
		TotalPriceUSD float64
		TotalPriceBs  string
		ExchangeRate  float64
	}{
		IsLoggedIn:    true,
		IsAdmin:       users[username].Role == "admin",
		Items:         items,
		TotalPriceUSD: totalPriceUSD,
		TotalPriceBs:  fmt.Sprintf("%.2f", totalPriceBs),
		ExchangeRate:  settings.ExchangeRate,
	}

	render(w, "checkout.html", data)
}

func confirmPaymentHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	username, ok := getUsernameFromSession(c.Value)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}

	userCart, exists := carts[username]
	if !exists || len(userCart) == 0 {
		http.Redirect(w, r, "/cart", http.StatusFound)
		return
	}

	reference := r.FormValue("reference")
	var orderItems []OrderItem
	var totalPriceUSD float64

	for gameID, quantity := range userCart {
		var game Game
		for _, g := range games {
			if g.ID == gameID {
				game = g
				break
			}
		}
		price := game.PriceUSD
		totalPriceUSD += price * float64(quantity)
		orderItems = append(orderItems, OrderItem{
			GameID:   gameID,
			Quantity: quantity,
			Price:    price,
		})
	}

	newOrder := Order{
		ID:               nextOrderID,
		Username:         username,
		Items:            orderItems,
		TotalPrice:       totalPriceUSD,
		PaymentReference: reference,
		Timestamp:        time.Now(),
		Status:           "Pending",
	}
	orders = append(orders, newOrder)
	nextOrderID++

	// Clear the cart
	delete(carts, username)

	log.Printf("New order received: ID %d from user %s", newOrder.ID, username)

	// Send sale notification email
	go sendSaleNotification(newOrder)

	http.Redirect(w, r, fmt.Sprintf("/confirmation?order_id=%d", newOrder.ID), http.StatusFound)
}

func confirmationPageHandler(w http.ResponseWriter, r *http.Request) {
	orderIDStr := r.URL.Query().Get("order_id")
	c, err := r.Cookie("session_token")
	isLoggedIn := false
	isAdmin := false
	if err == nil {
		username, ok := getUsernameFromSession(c.Value)
		if ok {
			isLoggedIn = true
			isAdmin = users[username].Role == "admin"
		}
	}
	data := struct {
		IsLoggedIn bool
		IsAdmin    bool
		OrderID    string
	}{
		IsLoggedIn: isLoggedIn,
		IsAdmin:    isAdmin,
		OrderID:    orderIDStr,
	}
	render(w, "confirmation.html", data)
}

func adminHandler(w http.ResponseWriter, r *http.Request) {
	data := struct {
		IsLoggedIn   bool
		IsAdmin      bool
		ExchangeRate float64
	}{
		IsLoggedIn:   true,
		IsAdmin:      true,
		ExchangeRate: settings.ExchangeRate,
	}
	render(w, "admin.html", data)
}

func updateRateHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}
	rateStr := r.FormValue("rate")
	rate, err := strconv.ParseFloat(rateStr, 64)
	if err != nil {
		http.Error(w, "Invalid rate value", http.StatusBadRequest)
		return
	}
	settings.ExchangeRate = rate
	log.Printf("Exchange rate updated to: %f", rate)
	http.Redirect(w, r, "/admin", http.StatusFound)
}

func uploadGameHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}
	r.ParseMultipartForm(10 << 20)
	file, handler, err := r.FormFile("image")
	if err != nil {
		http.Error(w, "Error retrieving the file", http.StatusBadRequest)
		return
	}
	defer file.Close()
	dstPath := filepath.Join("static", "images", handler.Filename)
	dst, err := os.Create(dstPath)
	if err != nil {
		http.Error(w, "Error creating the file", http.StatusInternalServerError)
		return
	}
	defer dst.Close()
	if _, err := io.Copy(dst, file); err != nil {
		http.Error(w, "Error saving the file", http.StatusInternalServerError)
		return
	}
	name := r.FormValue("name")
	priceStr := r.FormValue("price")
	console := r.FormValue("console")
	price, err := strconv.ParseFloat(priceStr, 64)
	if err != nil {
		http.Error(w, "Invalid price value", http.StatusBadRequest)
		return
	}
	newID := len(games) + 1
	imageURL := "/" + filepath.ToSlash(dstPath)
	newGame := Game{
		ID:       newID,
		Name:     name,
		Console:  console,
		PriceUSD: price,
		ImageURL: imageURL,
	}
	games = append(games, newGame)
	log.Printf("New game uploaded: %s", newGame.Name)
	http.Redirect(w, r, "/admin", http.StatusFound)
}

type ReportOrder struct {
	Order         Order
	NumberOfItems int
}

func reportsHandler(w http.ResponseWriter, r *http.Request) {
	now := time.Now()
	currentMonth := now.Month()
	currentYear := now.Year()
	var currentMonthSales = 0
	for _, order := range orders {
		if order.Timestamp.Month() == currentMonth && order.Timestamp.Year() == currentYear {
			currentMonthSales += len(order.Items)
		}
	}
	nextMonthProjection := currentMonthSales

	reportOrders := []ReportOrder{}
	for _, order := range orders {
		reportOrders = append(reportOrders, ReportOrder{
			Order:         order,
			NumberOfItems: len(order.Items),
		})
	}

	data := struct {
		IsLoggedIn          bool
		IsAdmin             bool
		CurrentMonthSales   int
		NextMonthProjection int
		Orders              []ReportOrder
	}{
		IsLoggedIn:          true,
		IsAdmin:             true,
		CurrentMonthSales:   currentMonthSales,
		NextMonthProjection: nextMonthProjection,
		Orders:              reportOrders,
	}

	render(w, "reports.html", data)
}

// --- User Management Handlers ---

func viewUsersHandler(w http.ResponseWriter, r *http.Request) {
	var userList []User
	for _, user := range users {
		userList = append(userList, user)
	}

	data := struct {
		IsLoggedIn     bool
		IsAdmin        bool
		Users          []User
		SuccessMessage string
		ErrorMessage   string
	}{
		IsLoggedIn: true,
		IsAdmin:    true,
		Users:      userList,
	}
	render(w, "users.html", data)
}

func createUserHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	username := r.FormValue("username")
	email := r.FormValue("email")
	password := r.FormValue("password")
	role := r.FormValue("role")

	if _, exists := users[username]; exists {
		// Handle error - maybe pass a message back to the page
		http.Redirect(w, r, "/admin/users", http.StatusFound)
		return
	}

	hashedPassword, err := hashPassword(password)
	if err != nil {
		http.Error(w, "Server error", http.StatusInternalServerError)
		return
	}

	users[username] = User{
		Username:     username,
		Email:        email,
		PasswordHash: hashedPassword,
		Role:         role,
	}
	log.Printf("Admin created new user: %s with role %s", username, role)
	http.Redirect(w, r, "/admin/users", http.StatusFound)
}

func deleteUserHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	username := r.FormValue("username")
	if username == "angelhe91" {
		// Maybe set an error message
		http.Redirect(w, r, "/admin/users", http.StatusFound)
		return
	}

	delete(users, username)
	log.Printf("Admin deleted user: %s", username)
	http.Redirect(w, r, "/admin/users", http.StatusFound)
}

func adminChangePasswordPageHandler(w http.ResponseWriter, r *http.Request) {
	targetUsername := r.URL.Query().Get("username")
	targetUser, ok := users[targetUsername]
	if !ok {
		http.Error(w, "User not found", http.StatusNotFound)
		return
	}

	data := struct {
		IsLoggedIn bool
		IsAdmin    bool
		TargetUser User
	}{
		IsLoggedIn: true,
		IsAdmin:    true,
		TargetUser: targetUser,
	}
	render(w, "admin_change_password.html", data)
}

func adminSetPasswordHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	// Get the logged-in admin
	c, _ := r.Cookie("session_token")
	loggedInAdminUsername, _ := getUsernameFromSession(c.Value)

	targetUsername := r.FormValue("username")
	newPassword := r.FormValue("new_password")

	targetUser := users[targetUsername]

	// Enforce password change rules
	// A regular admin cannot change another admin's password
	if loggedInAdminUsername != "angelhe91" && targetUser.Role == "admin" {
		// Maybe redirect with an error message
		http.Redirect(w, r, "/admin/users", http.StatusFound)
		return
	}

	newHashedPassword, err := hashPassword(newPassword)
	if err != nil {
		http.Error(w, "Server error", http.StatusInternalServerError)
		return
	}

	targetUser.PasswordHash = newHashedPassword
	users[targetUsername] = targetUser

	log.Printf("Admin '%s' changed password for user '%s'", loggedInAdminUsername, targetUsername)
	http.Redirect(w, r, "/admin/users", http.StatusFound)
}

// --- Profile Handlers ---

func profileHandler(w http.ResponseWriter, r *http.Request) {
	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	username, ok := getUsernameFromSession(c.Value)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}

	data := struct {
		IsLoggedIn     bool
		IsAdmin        bool
		SuccessMessage string
		ErrorMessage   string
	}{
		IsLoggedIn:     true,
		IsAdmin:        users[username].Role == "admin",
		SuccessMessage: r.URL.Query().Get("success"),
		ErrorMessage:   r.URL.Query().Get("error"),
	}
	render(w, "profile.html", data)
}

func changePasswordHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	username, ok := getUsernameFromSession(c.Value)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}

	currentPassword := r.FormValue("current_password")
	newPassword := r.FormValue("new_password")
	confirmPassword := r.FormValue("confirm_password")

	user := users[username]
	if !checkPasswordHash(currentPassword, user.PasswordHash) {
		http.Redirect(w, r, "/profile?error=Incorrect+current+password", http.StatusFound)
		return
	}

	if newPassword != confirmPassword {
		http.Redirect(w, r, "/profile?error=New+passwords+do+not+match", http.StatusFound)
		return
	}

	newHashedPassword, err := hashPassword(newPassword)
	if err != nil {
		http.Error(w, "Server error", http.StatusInternalServerError)
		return
	}

	user.PasswordHash = newHashedPassword
	users[username] = user

	http.Redirect(w, r, "/profile?success=Password+updated+successfully", http.StatusFound)
}

// --- My Games Page Handler ---

type PurchaseInfo struct {
	GameName  string
	OrderID   int
	Status    string
	SerialKey string
}

func myGamesHandler(w http.ResponseWriter, r *http.Request) {
	c, err := r.Cookie("session_token")
	if err != nil {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}
	username, ok := getUsernameFromSession(c.Value)
	if !ok {
		http.Redirect(w, r, "/login", http.StatusFound)
		return
	}

	var purchases []PurchaseInfo
	// Create a map of games for easy lookup
	gamesMap := make(map[int]Game)
	for _, game := range games {
		gamesMap[game.ID] = game
	}

	for _, order := range orders {
		if order.Username == username {
			for _, item := range order.Items {
				purchase := PurchaseInfo{
					GameName: gamesMap[item.GameID].Name,
					OrderID:  order.ID,
					Status:   order.Status,
				}
				if order.Status == "Approved" {
					// Find the delivered serial key
					for _, delivered := range deliveredGames {
						if delivered.OrderID == order.ID && delivered.GameID == item.GameID {
							purchase.SerialKey = delivered.SerialKey
							break
						}
					}
				}
				purchases = append(purchases, purchase)
			}
		}
	}

	data := struct {
		IsLoggedIn bool
		IsAdmin    bool
		Purchases  []PurchaseInfo
	}{
		IsLoggedIn: true,
		IsAdmin:    users[username].Role == "admin",
		Purchases:  purchases,
	}
	render(w, "my_games.html", data)
}

// --- Admin Approval Handlers ---

func viewPendingOrdersHandler(w http.ResponseWriter, r *http.Request) {
	var pendingOrders []Order
	for _, order := range orders {
		if order.Status == "Pending" {
			pendingOrders = append(pendingOrders, order)
		}
	}

	data := struct {
		IsLoggedIn    bool
		IsAdmin       bool
		PendingOrders []Order
	}{
		IsLoggedIn:    true,
		IsAdmin:       true,
		PendingOrders: pendingOrders,
	}
	render(w, "approve_orders.html", data)
}

func approvalFormHandler(w http.ResponseWriter, r *http.Request) {
	orderIDStr := r.URL.Query().Get("order_id")
	orderID, _ := strconv.Atoi(orderIDStr)

	var targetOrder Order
	for _, order := range orders {
		if order.ID == orderID {
			targetOrder = order
			break
		}
	}

	// Create a map of games for easy lookup in the template
	gamesMap := make(map[int]Game)
	for _, game := range games {
		gamesMap[game.ID] = game
	}

	data := struct {
		IsLoggedIn bool
		IsAdmin    bool
		Order      Order
		Games      map[int]Game
	}{
		IsLoggedIn: true,
		IsAdmin:    true,
		Order:      targetOrder,
		Games:      gamesMap,
	}
	render(w, "approve_form.html", data)
}

func processApprovalHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	orderIDStr := r.FormValue("order_id")
	orderID, _ := strconv.Atoi(orderIDStr)

	var orderIndex = -1
	var targetOrder Order
	for i, order := range orders {
		if order.ID == orderID {
			targetOrder = order
			orderIndex = i
			break
		}
	}

	if orderIndex == -1 {
		http.Error(w, "Order not found", http.StatusNotFound)
		return
	}

	// Update order status
	orders[orderIndex].Status = "Approved"

	// Create delivered game records with serial keys
	for _, item := range targetOrder.Items {
		serialKey := r.FormValue(fmt.Sprintf("serial_%d", item.GameID))
		deliveredGame := DeliveredGame{
			Username:  targetOrder.Username,
			OrderID:   targetOrder.ID,
			GameID:    item.GameID,
			SerialKey: serialKey,
		}
		deliveredGames = append(deliveredGames, deliveredGame)
	}

	log.Printf("Admin approved Order #%d", targetOrder.ID)
	http.Redirect(w, r, "/admin/approve-orders", http.StatusFound)
}
