package main

import (
	"time"
	"github.com/google/uuid"
	"golang.org/x/crypto/bcrypt"
)

// User represents a registered user.
type User struct {
	Username     string
	Email        string
	PasswordHash string
	Role         string // "admin" or "client"
}

// Game represents a game available for sale.
type Game struct {
	ID         int
	Name       string
	Console    string
	PriceUSD   float64
	ImageURL   string
}

// Order represents a customer's purchase of one or more games.
type Order struct {
	ID               int
	Username         string
	Items            []OrderItem
	TotalPrice       float64
	PaymentReference string
	Timestamp        time.Time
	Status           string // "Pending", "Approved", "Rejected"
}

// OrderItem represents a single item within an order.
type OrderItem struct {
	GameID   int
	Quantity int
	Price    float64 // Price per item at time of purchase
}

// StoreSettings holds the application settings.
type StoreSettings struct {
	ExchangeRate float64
}

// --- In-Memory Database ---

var (
	// games holds the list of games. I'll add some sample data.
	games = []Game{
		{ID: 1, Name: "Galactic Conquest", PriceUSD: 29.99, ImageURL: "/static/images/game1.jpg"},
		{ID: 2, Name: "Mystic Forest", PriceUSD: 19.99, ImageURL: "/static/images/game2.jpg"},
		{ID: 3, Name: "Cyberpunk Racer", PriceUSD: 39.99, ImageURL: "/static/images/game3.jpg"},
	}

	// orders holds the list of completed orders.
	orders = []Order{}

	// settings holds the current store settings.
	settings = StoreSettings{
		ExchangeRate: 36.5, // Initial dummy rate
	}

	// nextOrderID is a simple counter for new order IDs.
	nextOrderID = 1

	// users holds the registered users.
	users = map[string]User{} // map[username]User

	// sessions holds the active user sessions.
	sessions = map[string]string{} // map[sessionToken]username

	// carts holds the shopping carts for each user.
	// map[username]map[gameID]quantity
	carts = map[string]map[int]int{}

	// deliveredGames holds the games that have been approved and have a serial key.
	deliveredGames = []DeliveredGame{}
)

// DeliveredGame links a user to a specific game from an order and its serial key.
type DeliveredGame struct {
	Username  string
	OrderID   int
	GameID    int
	SerialKey string
}

// hashPassword hashes a password using bcrypt.
func hashPassword(password string) (string, error) {
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), 14)
	return string(bytes), err
}

// checkPasswordHash checks if a password matches a hash.
func checkPasswordHash(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}

// createSession creates a new session for a user.
func createSession(username string) string {
	sessionToken := uuid.New().String()
	sessions[sessionToken] = username
	return sessionToken
}

// getUsernameFromSession retrieves the username from a session token.
func getUsernameFromSession(sessionToken string) (string, bool) {
	username, ok := sessions[sessionToken]
	return username, ok
}

// deleteSession removes a session.
func deleteSession(sessionToken string) {
	delete(sessions, sessionToken)
}
