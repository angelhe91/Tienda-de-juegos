package main

import (
	"fmt"
	"log"
)

// sendSaleNotification simulates sending an email to the admin when a sale occurs.
// In a real application, this would use net/smtp to send a real email.
func sendSaleNotification(order Order) {
	to := "Angelhe91@gmail.com"
	subject := fmt.Sprintf("New Sale! Order #%d", order.ID)

	body := "A new sale has been made on your store.\n\n"
	body += fmt.Sprintf("Order ID: %d\n", order.ID)
	body += fmt.Sprintf("Customer: %s\n", order.Username)
	body += fmt.Sprintf("Total Price: $%.2f\n", order.TotalPrice)
	body += "Items:\n"
	for _, item := range order.Items {
		// In a real app, you'd look up the game name here.
		// For simplicity, we'll just use the ID.
		body += fmt.Sprintf("- Game ID: %d, Quantity: %d, Price: $%.2f\n", item.GameID, item.Quantity, item.Price)
	}

	log.Println("--- SIMULATING EMAIL ---")
	log.Printf("To: %s\n", to)
	log.Printf("Subject: %s\n", subject)
	log.Printf("Body: \n%s\n", body)
	log.Println("----------------------")
}

// sendRegistrationConfirmation simulates sending a welcome email to a new user.
// In a real application, this would use net/smtp to send a real email.
func sendRegistrationConfirmation(user User) {
	to := user.Email
	subject := "Welcome to the Virtual Game Store!"

	body := fmt.Sprintf("Hi %s,\n\n", user.Username)
	body += "Thank you for registering at our store!\n"
	body += "You can now browse and purchase games.\n"
	body += "Return to the store here: http://localhost:8080/\n\n"
	body += "Thanks,\nThe Store Team"

	log.Println("--- SIMULATING EMAIL ---")
	log.Printf("To: %s\n", to)
	log.Printf("Subject: %s\n", subject)
	log.Printf("Body: \n%s\n", body)
	log.Println("----------------------")
}
